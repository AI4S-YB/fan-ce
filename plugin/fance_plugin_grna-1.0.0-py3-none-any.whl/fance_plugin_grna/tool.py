"""gRNA Design tool — finds CRISPR guide RNA candidates in a target sequence."""
import os, re, math
from basis.analysis.base import (
    BaseAnalysisTool, TextParam, ChoiceParam, IntParam, FileOutput,
)

PAM_PATTERNS = {
    "NGG": r"(?=(.{21}GG))",
    "NRG": r"(?=(.{21}[AG]G))",
    "NGA": r"(?=(.{21}GA))",
}

class GrnaDesignTool(BaseAnalysisTool):
    tool_id = "grna"
    tool_version = "1.0.0"
    display_name = "gRNA Design"
    description = "Design CRISPR guide RNAs by scanning for PAM sites in a target DNA sequence."
    category = "utility"

    inputs = []

    parameters = [
        TextParam(name="target_seq", label="Target DNA Sequence", default="",
                  description="Paste the target DNA sequence (raw or FASTA format)."),
        ChoiceParam(name="pam", label="PAM Sequence", choices=["NGG", "NRG", "NGA"], default="NGG"),
        IntParam(name="gc_min", label="Min GC Content (%)", default=30, min=0, max=100),
        IntParam(name="gc_max", label="Max GC Content (%)", default=80, min=0, max=100),
        IntParam(name="grna_len", label="gRNA Length (without PAM)", default=20, min=18, max=23),
    ]

    outputs = [
        FileOutput(name="grna_table", format="tsv", label="gRNA Candidates", display="table"),
    ]

    timeout_seconds = 120
    dependencies = {}

    def build_command(self, file_paths: dict, params: dict, work_dir: str) -> list:
        target_seq = params.get("target_seq", "")
        script = self._generate_script(params, work_dir)
        script_path = os.path.join(work_dir, "run_grna.py")
        with open(script_path, "w") as f:
            f.write(script)
        # Write target sequence to a file for the script to read
        seq_path = os.path.join(work_dir, "target.fa")
        with open(seq_path, "w") as f:
            f.write(f">target\n{target_seq}\n")
        return ["python", script_path]

    def validate_outputs(self, work_dir: str) -> list:
        p = os.path.join(work_dir, "grna_table.tsv")
        return [p] if os.path.exists(p) else []

    def _generate_script(self, params, work_dir):
        pam = params.get("pam", "NGG")
        gc_min = params.get("gc_min", 30)
        gc_max = params.get("gc_max", 80)
        grna_len = params.get("grna_len", 20)
        return f'''
import os, re

os.chdir("{work_dir}")

# Read target sequence
target = ""
with open("target.fa") as f:
    for line in f:
        if not line.startswith(">"):
            target += line.strip().upper()

target_clean = re.sub(r'[^ATCG]', '', target)
print(f"Target length: {{len(target_clean)}} bp")

# PAM scanning
pam = "{pam}"
if pam == "NGG":
    pattern = r"(?=(.{{{grna_len}}}GG))"
elif pam == "NRG":
    pattern = r"(?=(.{{{grna_len}}}[AG]G))"
else:
    pattern = r"(?=(.{{{grna_len}}}GA))"

gc_min = {gc_min}
gc_max = {gc_max}

results = []
for m in re.finditer(pattern, target_clean):
    start = m.start()
    grna = m.group(1)
    seq = grna[:{grna_len}]
    pam_seq = grna[{grna_len}:]
    gc = (seq.count('G') + seq.count('C')) / len(seq) * 100
    if gc >= gc_min and gc <= gc_max:
        results.append((start + 1, seq, pam_seq, f"{{gc:.1f}}%", len(seq)))

print(f"Found {{len(results)}} gRNA candidates")

with open("{work_dir}/grna_table.tsv", "w") as out:
    out.write("Position\\tgRNA_Sequence\\tPAM\\tGC_Content\\tLength\\n")
    for pos, seq, pam_seq, gc, length in results:
        out.write(f"{{pos}}\\t{{seq}}\\t{{pam_seq}}\\t{{gc}}\\t{{length}}\\n")
'''
