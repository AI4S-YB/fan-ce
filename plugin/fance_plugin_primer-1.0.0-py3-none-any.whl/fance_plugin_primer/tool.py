"""Primer Design tool — wrapper around Primer3 for PCR primer design."""
import os, subprocess
from basis.analysis.base import (
    BaseAnalysisTool, TextParam, IntParam, FloatParam, FileOutput,
)

class PrimerTool(BaseAnalysisTool):
    tool_id = "primer"
    tool_version = "1.0.0"
    display_name = "Primer Design"
    description = "Design PCR primers using Primer3. Paste a template DNA sequence."
    category = "utility"

    inputs = []

    parameters = [
        TextParam(name="template_seq", label="Template DNA Sequence", default="",
                  description="Paste the template DNA sequence."),
        IntParam(name="product_min", label="Min Product Size (bp)", default=100, min=50, max=10000),
        IntParam(name="product_max", label="Max Product Size (bp)", default=500, min=50, max=10000),
        FloatParam(name="tm_min", label="Min Tm (°C)", default=55, min=40, max=70),
        FloatParam(name="tm_max", label="Max Tm (°C)", default=65, min=40, max=70),
        IntParam(name="primer_size_opt", label="Optimal Primer Size (bp)", default=20, min=15, max=30),
        IntParam(name="gc_clamp", label="3' GC Clamp", default=1, min=0, max=5),
    ]

    outputs = [
        FileOutput(name="primer_table", format="tsv", label="Primer Pairs", display="table"),
    ]

    timeout_seconds = 120
    dependencies = {"conda": ["primer3"]}

    def build_command(self, file_paths: dict, params: dict, work_dir: str) -> list:
        template = params.get("template_seq", "")
        script = self._generate_script(params, work_dir)
        script_path = os.path.join(work_dir, "run_primer.py")
        with open(script_path, "w") as f:
            f.write(script)
        return ["python", script_path]

    def validate_outputs(self, work_dir: str) -> list:
        p = os.path.join(work_dir, "primer_table.tsv")
        return [p] if os.path.exists(p) else []

    def _generate_script(self, params, work_dir):
        return f'''
import os, subprocess, re, tempfile

os.chdir("{work_dir}")
template = """{params.get("template_seq", "")}"""
template = re.sub(r'[^ATCGatcg]', '', template).upper()

product_min = {params.get("product_min", 100)}
product_max = {params.get("product_max", 500)}
tm_min = {params.get("tm_min", 55)}
tm_max = {params.get("tm_max", 65)}
primer_opt = {params.get("primer_size_opt", 20)}
gc_clamp = {params.get("gc_clamp", 1)}

# Write primer3 input
boulder = f"""SEQUENCE_ID=target
SEQUENCE_TEMPLATE={{template}}
PRIMER_TASK=generic
PRIMER_PICK_LEFT_PRIMER=1
PRIMER_PICK_RIGHT_PRIMER=1
PRIMER_PRODUCT_SIZE_RANGE={{product_min}}-{{product_max}}
PRIMER_MIN_TM={{tm_min}}
PRIMER_OPT_TM={{(tm_min+tm_max)/2:.1f}}
PRIMER_MAX_TM={{tm_max}}
PRIMER_OPT_SIZE={{primer_opt}}
PRIMER_NUM_RETURN=10
PRIMER_GC_CLAMP={{gc_clamp}}
="""

with open("primer3_input.txt", "w") as f:
    f.write(boulder)

# Run primer3
try:
    result = subprocess.run(["primer3_core", "primer3_input.txt"],
                          capture_output=True, text=True, timeout=60)
    output = result.stdout
except FileNotFoundError:
    output = "PRIMER_ERROR=primer3_core not installed\\n"
except Exception as e:
    output = f"PRIMER_ERROR={{e}}\\n"

# Parse output
primers = {{}}
for line in output.strip().split("\\n"):
    if "=" in line:
        key, val = line.split("=", 1)
        primers[key] = val

# Extract primer pairs
with open("{work_dir}/primer_table.tsv", "w") as out:
    out.write("Pair\\tLeft_Primer\\tLeft_Tm\\tLeft_GC%\\tRight_Primer\\tRight_Tm\\tRight_GC%\\tProduct_Size\\n")
    for i in range(10):
        lp = primers.get(f"PRIMER_LEFT_{{i}}_SEQUENCE", "")
        if not lp:
            break
        rp = primers.get(f"PRIMER_RIGHT_{{i}}_SEQUENCE", "")
        ltm = primers.get(f"PRIMER_LEFT_{{i}}_TM", "0")
        rtm = primers.get(f"PRIMER_RIGHT_{{i}}_TM", "0")
        lgc = primers.get(f"PRIMER_LEFT_{{i}}_GC_PERCENT", "0")
        rgc = primers.get(f"PRIMER_RIGHT_{{i}}_GC_PERCENT", "0")
        psize = primers.get(f"PRIMER_PAIR_{{i}}_PRODUCT_SIZE", "0")
        out.write(f"{{i+1}}\\t{{lp}}\\t{{ltm}}\\t{{lgc}}\\t{{rp}}\\t{{rtm}}\\t{{rgc}}\\t{{psize}}\\n")

print(f"Found {{i}} primer pairs")
'''
