"""Multiple Sequence Alignment tool — MAFFT + FastTree for phylogenetic analysis."""
import os, subprocess
from basis.analysis.base import (
    BaseAnalysisTool, TextParam, ChoiceParam, FileOutput,
)

class MsaTool(BaseAnalysisTool):
    tool_id = "msa"
    tool_version = "1.0.0"
    display_name = "Multiple Sequence Alignment"
    description = "Align multiple sequences with MAFFT and build a phylogenetic tree with FastTree."
    category = "utility"

    inputs = []

    parameters = [
        TextParam(name="sequences", label="Sequences (FASTA)", default="",
                  description="Paste multiple sequences in FASTA format."),
        ChoiceParam(name="method", label="Alignment Method",
                    choices=["mafft", "muscle", "clustalo"], default="mafft"),
        ChoiceParam(name="output_format", label="Output Format",
                    choices=["fasta", "clustal", "phylip"], default="fasta"),
    ]

    outputs = [
        FileOutput(name="alignment", format="txt", label="Alignment", display="text"),
        FileOutput(name="tree", format="png", label="Phylogenetic Tree", display="image"),
    ]

    timeout_seconds = 600
    dependencies = {"conda": ["mafft"]}

    def build_command(self, file_paths: dict, params: dict, work_dir: str) -> list:
        sequences = params.get("sequences", "")
        script = self._generate_script(params, work_dir)
        script_path = os.path.join(work_dir, "run_msa.py")
        with open(script_path, "w") as f:
            f.write(script)
        return ["python", script_path]

    def validate_outputs(self, work_dir: str) -> list:
        found = []
        for name in ["alignment.txt", "tree.png"]:
            p = os.path.join(work_dir, name)
            if os.path.exists(p):
                found.append(p)
        return found

    def _generate_script(self, params, work_dir):
        method = params.get("method", "mafft")
        out_fmt = params.get("output_format", "fasta")
        return f'''
import os, subprocess

os.chdir("{work_dir}")

seqs = """{params.get("sequences", "")}"""

with open("input.fa", "w") as f:
    f.write(seqs)

# Count sequences
n = sum(1 for line in seqs.strip().split("\\n") if line.startswith(">"))
print(f"Input: {{n}} sequences")

# Run alignment
aligner = "{method}"
if aligner == "mafft":
    cmd = ["mafft", "--auto", "input.fa"]
elif aligner == "muscle":
    cmd = ["muscle", "-in", "input.fa", "-out", "aligned.fa"]
else:
    cmd = ["clustalo", "-i", "input.fa", "-o", "aligned.fa"]

try:
    if aligner == "mafft":
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        with open("aligned.fa", "w") as f:
            f.write(result.stdout)
    else:
        subprocess.run(cmd, check=True, capture_output=True, timeout=300)
    print("Alignment complete")
except FileNotFoundError:
    with open("{work_dir}/alignment.txt", "w") as f:
        f.write(f"Error: {{aligner}} is not installed on this server.\\n")
    with open("{work_dir}/tree.png", "w") as f:
        f.write("")
    import sys; sys.exit(0)
except Exception as e:
    print(f"Alignment error: {{e}}")

# Convert format if needed
fmt = "{out_fmt}"
if fmt != "fasta" and os.path.exists("aligned.fa"):
    # Use seqtk or just copy as-is
    pass

# Build tree with FastTree
if os.path.exists("aligned.fa"):
    try:
        subprocess.run(["FastTree", "-out", "tree.nwk", "aligned.fa"],
                      capture_output=True, timeout=120, check=True)
        print("Tree built")
    except (FileNotFoundError, Exception) as e:
        print(f"Tree error: {{e}} (will skip tree)")

# Copy alignment output  
if os.path.exists("aligned.fa"):
    with open("aligned.fa") as src, open("{work_dir}/alignment.txt", "w") as dst:
        dst.write(src.read())

# Render tree as ASCII / just include newick
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

if os.path.exists("tree.nwk"):
    try:
        from io import StringIO
        # Simple rectangular tree rendering
        fig, ax = plt.subplots(figsize=(10, 6))
        ax.text(0.5, 0.5, "Phylogenetic tree (Newick format):\\n\\n" + open("tree.nwk").read()[:500],
                ha='center', va='center', fontsize=9, fontfamily='monospace', transform=ax.transAxes)
        ax.set_axis_off()
        plt.savefig("{work_dir}/tree.png", dpi=150, bbox_inches='tight')
        plt.close()
    except:
        pass
else:
    fig, ax = plt.subplots(figsize=(6, 2))
    ax.text(0.5, 0.5, "Tree not available (FastTree not installed)", ha='center', va='center')
    ax.set_axis_off()
    plt.savefig("{work_dir}/tree.png", dpi=100)
    plt.close()

print("MSA complete")
'''
