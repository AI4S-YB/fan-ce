"""Multiple Sequence Alignment tool — MAFFT + FastTree for phylogenetic analysis."""
import os, subprocess
from basis.analysis.base import (
    BaseAnalysisTool, TextParam, ChoiceParam, FileOutput,
)

class MsaTool(BaseAnalysisTool):
    tool_id = "msa"
    tool_version = "1.0.0"
    display_name = "Multiple Sequence Alignment"
    description = "Align multiple sequences with MAFFT and build a phylogenetic tree with FastTree."
    category = "utility"

    inputs = []
    parameters = [
        TextParam(name="sequences", label="Sequences (FASTA)", default="",
                  description="Paste multiple sequences in FASTA format."),
        ChoiceParam(name="method", label="Alignment Method",
                    choices=["mafft", "muscle", "clustalo"], default="mafft"),
        ChoiceParam(name="output_format", label="Output Format",
                    choices=["fasta", "clustal"], default="fasta"),
    ]
    outputs = [
        FileOutput(name="alignment", format="txt", label="Alignment", display="text"),
        FileOutput(name="tree", format="txt", label="Phylogenetic Tree (Newick)", display="text"),
    ]
    timeout_seconds = 600
    dependencies = {"conda": ["mafft"]}

    def build_command(self, file_paths: dict, params: dict, work_dir: str) -> list:
        script = self._generate_script(params, work_dir)
        script_path = os.path.join(work_dir, "run_msa.py")
        with open(script_path, "w") as f:
            f.write(script)
        return ["python", script_path]

    def validate_outputs(self, work_dir: str) -> list:
        found = []
        for name in ["alignment.txt", "tree.txt"]:
            p = os.path.join(work_dir, name)
            if os.path.exists(p):
                found.append(p)
        return found

    def _generate_script(self, params, work_dir):
        method = params.get("method", "mafft")
        return f'''
import os, subprocess

os.chdir("{work_dir}")
seqs = """{params.get("sequences", "")}"""

with open("input.fa", "w") as f:
    f.write(seqs)

n = sum(1 for line in seqs.strip().split("\\n") if line.startswith(">"))
print(f"Input: {{n}} sequences")

aligner = "{method}"

# Run MAFFT
try:
    result = subprocess.run(["mafft", "--auto", "input.fa"],
                          capture_output=True, text=True, timeout=300)
    with open("aligned.fa", "w") as f:
        f.write(result.stdout)
    print(f"Alignment complete, length={{len(result.stdout)}}")
except FileNotFoundError:
    msg = f"Error: mafft is not installed on this server.\\n"
    with open("{work_dir}/alignment.txt", "w") as f: f.write(msg)
    with open("{work_dir}/tree.txt", "w") as f: f.write(msg)
    import sys; sys.exit(0)
except Exception as e:
    print(f"Alignment error: {{e}}")

# Copy alignment
if os.path.exists("aligned.fa"):
    with open("aligned.fa") as src, open("{work_dir}/alignment.txt", "w") as dst:
        dst.write(src.read())

# Build tree with FastTree
if os.path.exists("aligned.fa"):
    try:
        subprocess.run(["FastTree", "-out", "tree.nwk", "aligned.fa"],
                      capture_output=True, timeout=120, check=True)
        with open("tree.nwk") as src, open("{work_dir}/tree.txt", "w") as dst:
            dst.write(src.read())
        print("Tree built")
    except FileNotFoundError:
        with open("{work_dir}/tree.txt", "w") as f:
            f.write("FastTree not installed. Newick tree not available.\\n")
    except Exception as e:
        with open("{work_dir}/tree.txt", "w") as f:
            f.write(f"Tree error: {{e}}\\n")
else:
    with open("{work_dir}/tree.txt", "w") as f:
        f.write("No alignment available for tree building.\\n")

print("MSA complete")
'''
