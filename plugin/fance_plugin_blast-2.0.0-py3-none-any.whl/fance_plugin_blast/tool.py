"""BLAST tool — nucleotide and protein sequence similarity search."""
import os, re, subprocess, xml.etree.ElementTree as ET
from basis.analysis.base import (
    BaseAnalysisTool, TextParam, ChoiceParam, FloatParam, IntParam, FileOutput,
)

LINK_PATTERNS = [
    (r'^sp\||^tr\|', lambda acc: f'https://www.uniprot.org/uniprot/{acc.split("|")[-1]}'),
    (r'^gi\|', lambda acc: f'https://www.ncbi.nlm.nih.gov/protein/{acc.split("|")[-1]}'),
    (r'^AT[1-5MC]G\d', lambda acc: f'https://www.arabidopsis.org/servlets/TairObject?type=locus&name={acc}'),
]


class BlastTool(BaseAnalysisTool):
    tool_id = "blast"
    tool_version = "2.0.0"
    display_name = "BLAST"
    description = "BLAST sequence similarity search against local databases."
    category = "utility"
    inputs = []
    parameters = [
        TextParam(name="query_seq", label="Query Sequence (FASTA)", default="",
                  description="Paste one or more sequences in FASTA format."),
        ChoiceParam(name="database", label="Database", choices=[], default=""),
        ChoiceParam(name="seq_type", label="Sequence Type",
                    choices=["auto", "nucleotide", "protein"], default="auto"),
        FloatParam(name="evalue", label="E-value Threshold", default=1e-5, min=1e-100, max=1000),
        IntParam(name="max_hits", label="Max Hits", default=50, min=1, max=500),
    ]
    outputs = [
        FileOutput(name="blast_table", format="tsv", label="BLAST Results", display="table"),
        FileOutput(name="blast_report", format="txt", label="Full Report", display="text"),
    ]
    timeout_seconds = 600
    dependencies = {"conda": ["blast"]}

    def build_command(self, file_paths: dict, params: dict, work_dir: str) -> list:
        """Execute BLAST - writes config to JSON file, runs inline script."""
        import json as _json
        cfg = {
            "query": params.get("query_seq", ""),
            "database": params.get("database", ""),
            "seq_type": params.get("seq_type", "auto"),
            "evalue": params.get("evalue", 1e-5),
            "max_hits": params.get("max_hits", 50),
        }
        cfg_path = os.path.join(work_dir, "blast_cfg.json")
        with open(cfg_path, "w") as f:
            _json.dump(cfg, f)

        script_path = os.path.join(work_dir, "run_blast.py")
        with open(script_path, "w") as f:
            f.write(EXEC_SCRIPT)
        return ["python", script_path]

    def validate_outputs(self, work_dir: str) -> list:
        found = []
        for name in [os.path.join(work_dir, "blast_table.tsv"), "blast_report.txt"]:
            p = os.path.join(work_dir, name)
            if os.path.exists(p):
                found.append(p)
        return found


# Inline execution script (runs via build_command -> python run_blast.py)
EXEC_SCRIPT = r"""
import os, subprocess, re, xml.etree.ElementTree as ET, json

# Read config from file
with open(os.path.join(os.path.dirname(__file__), "blast_cfg.json")) as f:
    cfg = json.load(f)

work_dir = os.path.dirname(os.path.abspath(__file__))

# Write query
with open(os.path.join(work_dir, "query.fa"), "w") as f:
    f.write(cfg["query"])

db = cfg["database"]
if not db or not (os.path.exists(db + ".phr") or os.path.exists(db + ".pin")):
    with open(os.path.join(work_dir, "blast_table.tsv"), "w") as f:
        f.write("Error\tBLAST database not found or not indexed: " + db + "\n")
    with open(os.path.join(work_dir, "blast_report.txt"), "w") as f:
        f.write("BLAST database not found or not indexed.\n")
    raise SystemExit(0)

# Detect types
db_is_prot = os.path.exists(db + ".phr") or os.path.exists(db + ".pin")

def guess_type(fasta_path):
    with open(fasta_path) as f:
        seq = ""
        for line in f:
            if not line.startswith(">"):
                seq += line.strip().upper()
    dna = set("ATCGN")
    ndna = sum(1 for c in seq if c.isalpha() and c not in dna)
    return "prot" if (len(seq) > 0 and ndna / len(seq) > 0.1) else "nucl"

st = guess_type("query.fa") if cfg["seq_type"] == "auto" else cfg["seq_type"]
program = "blastp" if st == "prot" else "blastn"
if st == "prot" and not db_is_prot:
    program = "tblastn"
elif st != "prot" and db_is_prot:
    program = "blastx"

dbs = db.split()
print(f"Running {program} against {len(dbs)} database(s)...")

cmd = [program, "-query", "query.fa", "-db"] + dbs + [
       "-evalue", str(cfg["evalue"]), "-max_target_seqs", str(cfg["max_hits"]),
       "-outfmt", "5", "-out", "blast.xml"]
result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)

if result.returncode != 0 or not os.path.exists("blast.xml"):
    err = result.stderr[:300] if result.stderr else "Unknown"
    with open(os.path.join(work_dir, "blast_table.tsv"), "w") as f:
        f.write("Error\tBLAST failed: " + err.replace("\t"," ") + "\n")
    with open(os.path.join(work_dir, "blast_report.txt"), "w") as f:
        f.write(result.stderr or "Unknown error")
    raise SystemExit(0)

# Parse XML
def make_link(acc):
    for pat, fn in [
        (r'^sp\||^tr\|', lambda a: 'https://www.uniprot.org/uniprot/' + a.split('|')[-1]),
        (r'^gi\|', lambda a: 'https://www.ncbi.nlm.nih.gov/protein/' + a.split('|')[-1]),
    ]:
        if re.match(pat, acc):
            return fn(acc)
    return ""

try:
    tree = ET.parse("blast.xml")
    root = tree.getroot()
except Exception as e:
    with open(os.path.join(work_dir, "blast_table.tsv"), "w") as f:
        f.write("Error\tXML parse failed: " + str(e) + "\n")
    raise SystemExit(1)

out = os.path.join(work_dir, "blast_table.tsv")
rpt = os.path.join(work_dir, "blast_report.txt")
with open(out, "w") as f, open(rpt, "w") as r:
    f.write("Query\tHit_ID\tHit_Accession\tHit_Def\tLength\tScore\tEvalue\tIdentity\tPositives\tGaps\tQStart\tQEnd\tSStart\tSEnd\tQSeq\tSSeq\tMidline\tLink\n")
    for it in root.findall(".//Iteration"):
        qid = it.findtext("Iteration_query-def", "Query")
        r.write(f"Query: {qid}\n{'='*60}\n")
        for hit in it.findall(".//Hit"):
            hid = hit.findtext("Hit_id", "")
            ha = hit.findtext("Hit_accession", "")
            hd = hit.findtext("Hit_def", "")
            hl = hit.findtext("Hit_len", "")
            link = make_link(ha)
            r.write(f"\n> {hid}  [{hd}]  Length={hl}\n")
            for hsp in hit.findall(".//Hsp"):
                row = "\t".join([
                    qid, hid, ha, hd, hl,
                    hsp.findtext("Hsp_bit-score", ""),
                    hsp.findtext("Hsp_evalue", ""),
                    hsp.findtext("Hsp_identity", ""),
                    hsp.findtext("Hsp_positive", ""),
                    hsp.findtext("Hsp_gaps", ""),
                    hsp.findtext("Hsp_query-from", ""),
                    hsp.findtext("Hsp_query-to", ""),
                    hsp.findtext("Hsp_hit-from", ""),
                    hsp.findtext("Hsp_hit-to", ""),
                    hsp.findtext("Hsp_qseq", ""),
                    hsp.findtext("Hsp_hseq", ""),
                    hsp.findtext("Hsp_midline", ""),
                    link,
                ])
                f.write(row + "\n")
                # Text report
                r.write(f"  Score={hsp.findtext('Hsp_bit-score','')} E-value={hsp.findtext('Hsp_evalue','')} Identity={hsp.findtext('Hsp_identity','')}\n")
                r.write(f"  Query  {hsp.findtext('Hsp_query-from','')}-{hsp.findtext('Hsp_query-to','')}  {hsp.findtext('Hsp_qseq','')}\n")
                r.write(f"         {hsp.findtext('Hsp_midline','')}\n")
                r.write(f"  Sbjct  {hsp.findtext('Hsp_hit-from','')}-{hsp.findtext('Hsp_hit-to','')}  {hsp.findtext('Hsp_hseq','')}\n\n")

import sys; print(f"BLAST done: {len(open(out).readlines())-1} HSPs")
"""
