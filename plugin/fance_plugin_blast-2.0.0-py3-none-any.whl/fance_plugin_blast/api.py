"""BLAST plugin API router — provides BLAST-specific endpoints."""
import os, glob as _glob, subprocess, logging
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from db.database import get_db
from libs.responses.response import response_2000
from apps.common.depends import get_active_user

logger = logging.getLogger(__name__)
router = APIRouter(tags=["plugin:blast"])

DEFAULT_BLASTDB_DIR = "/Users/kentnf/projects/data/blastdb"


def _get_blastdb_dir() -> str:
    """Get the configured BLAST database directory."""
    return os.environ.get("BLASTDB_DIR", DEFAULT_BLASTDB_DIR)


# ── Settings endpoint ──

@router.get("/admin/blast/settings", summary="管理端：获取 BLAST 设置")
def admin_get_settings(_user=Depends(get_active_user)):
    return response_2000(data={
        "blastdb_dir": _get_blastdb_dir(),
        "indexed_count": len(_scan_blastdb_dir()),
        "db_names": _load_db_names(),
    })


@router.put("/admin/blast/settings", summary="管理端：更新 BLAST 设置")
def admin_update_settings(blastdb_dir: str = None, _user=Depends(get_active_user)):
    if blastdb_dir:
        os.environ["BLASTDB_DIR"] = blastdb_dir
        os.makedirs(blastdb_dir, exist_ok=True)
    return response_2000(data={"blastdb_dir": _get_blastdb_dir()})


@router.put("/admin/blast/databases/{db_key}/name", summary="管理端：设置 BLAST 数据库显示名称")
def admin_set_db_name(db_key: str, name: str, _user=Depends(get_active_user)):
    """Set a custom display name for a BLAST database."""
    names = _load_db_names()
    names[db_key] = name.strip()
    _save_db_names(names)
    return response_2000(data={"db_key": db_key, "name": names[db_key]})


def _guess_db_type_from_name(name: str, fmt: str = "") -> str:
    n = name.lower()
    if "protein" in n or "faa" in fmt:
        return "prot"
    return "nucl"


def _check_indexed(fp: str, name: str = "", dataset_code: str = "") -> bool:
    # Check in-place index files
    for ext in [".phr", ".pin", ".nhr", ".nin"]:
        if os.path.exists(fp + ext):
            return True
    # Check unified BLASTDB_DIR
    base = name.rsplit(".", 1)[0] if "." in name else name
    title = f"{dataset_code}_{base}".replace(" ", "_").replace("/", "_")[:50]
    return os.path.exists(os.path.join(_get_blastdb_dir(), title + ".phr")) or os.path.exists(os.path.join(_get_blastdb_dir(), title + ".nhr"))


def _scan_blastdb_dir() -> list[dict]:
    """Scan pre-built BLAST databases from BLASTDB_DIR."""
    results = []
    if not os.path.isdir(_get_blastdb_dir()):
        return results
    seen = set()
    for pattern in ["*.phr", "*.nhr"]:
        for idx_file in _glob.glob(os.path.join(_get_blastdb_dir(), pattern)):
            base = idx_file[:-4]
            if base in seen:
                continue
            seen.add(base)
            name = os.path.basename(base)
            db_type = "prot" if os.path.exists(base + ".pin") or os.path.exists(base + ".phr") else "nucl"
            if os.path.exists(base + ".nhr") or os.path.exists(base + ".nin"):
                db_type = "nucl"
            results.append({
                "id": 0, "name": name, "path": base,
                "format": "blastdb", "type": db_type,
                "size": 0, "dataset": "Pre-built BLAST DB",
                "dataset_code": name, "indexed": True,
            })
    return results


def _load_db_names() -> dict:
    """Load custom BLAST database display names from JSON file."""
    names_file = os.path.join(_get_blastdb_dir(), "blast_names.json")
    if os.path.exists(names_file):
        try:
            import json
            with open(names_file) as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def _save_db_names(names: dict):
    """Save custom BLAST database display names to JSON file."""
    import json
    os.makedirs(_get_blastdb_dir(), exist_ok=True)
    names_file = os.path.join(_get_blastdb_dir(), "blast_names.json")
    with open(names_file, "w") as f:
        json.dump(names, f, ensure_ascii=False, indent=2)


def _file_role_label(role: str) -> str:
    """Convert file_role to a human-readable sequence type label."""
    role = (role or "").lower()
    if "protein" in role:
        return "Protein"
    if "transcript" in role or "mrna" in role or "cds" in role:
        return "mRNA" if "mrna" in role else "CDS" if "cds" in role else "Transcript"
    if "gene_model" in role or "gff" in role:
        return "Gene Annotation"
    if "genome" in role or "reference" in role or role == "primary":
        return "Genome"
    return "Sequence"


def _build_db_name(dataset_title: str, file_name: str, file_role: str, file_format: str) -> str:
    """Generate a human-readable BLAST database name."""
    base = file_name.rsplit(".", 1)[0] if "." in file_name else file_name
    # Remove common suffixes
    for sfx in [".fa", ".fasta", ".fna", ".faa"]:
        if base.endswith(sfx):
            base = base[:-len(sfx)]
    label = _file_role_label(file_role)
    # If label already describes it, don't duplicate
    if label.lower() in base.lower():
        return f"{dataset_title} {file_name}"
    return f"{dataset_title} {label}"


def _resolve_db_entry(af, reg, db_type: str) -> dict | None:
    """Build a BLAST database entry for an AssetFile if it has a BLAST index."""
    fp = af.local_path or af.storage_uri or ""
    if not fp or not os.path.exists(fp):
        return None

    # Check if indexed in BLASTDB_DIR
    base_name = af.file_name.rsplit(".", 1)[0] if "." in (af.file_name or "") else (af.file_name or "unknown")
    title = f"{reg.dataset_code}_{base_name}".replace(" ", "_").replace("/", "_")[:50]
    idx_path = os.path.join(_get_blastdb_dir(), title)

    if not (os.path.exists(idx_path + ".phr") or os.path.exists(idx_path + ".nhr")):
        return None  # Not indexed

    # Custom name or auto-generated
    names = _load_db_names()
    custom_name = names.get(title, "").strip()

    return {
        "id": af.id,
        "name": custom_name or _build_db_name(reg.title or reg.dataset_code, af.file_name or "", af.file_role or "", af.file_format or ""),
        "path": idx_path,
        "db_key": title,
        "type": db_type,
        "size": af.file_size or 0,
        "dataset": reg.title or reg.dataset_code,
        "dataset_code": reg.dataset_code,
        "indexed": True,
    }


# ── Public endpoint ──

@router.get("/blast/databases", summary="列出可用的 BLAST 数据库")
def list_blast_databases(db: Session = Depends(get_db)):
    """List indexed BLAST databases with human-readable names."""
    from apps.datasets.models import AssetFile, DatasetAsset, DatasetVersion, DatasetRegistry

    results = []
    seen_paths = set()

    fasta_files = db.query(AssetFile, DatasetAsset, DatasetRegistry).join(
        DatasetAsset, AssetFile.dataset_asset_id == DatasetAsset.id
    ).join(
        DatasetVersion, DatasetAsset.dataset_version_id == DatasetVersion.id
    ).join(
        DatasetRegistry, DatasetVersion.database_id == DatasetRegistry.database_id
    ).filter(
        AssetFile.file_format.in_([
            "fa", "fasta", "fna", "faa", "fa.gz", "fasta.gz", "fna.gz", "faa.gz"
        ]),
        DatasetVersion.is_current == 1,
        DatasetRegistry.visibility == "public",
    ).all()

    for af, asset, reg in fasta_files:
        db_type = _guess_db_type_from_name(af.file_name or "", af.file_format or "")
        entry = _resolve_db_entry(af, reg, db_type)
        if entry and entry["path"] not in seen_paths:
            seen_paths.add(entry["path"])
            results.append(entry)

    # Also include orphan indexed DBs in BLASTDB_DIR not linked to AssetFiles
    names = _load_db_names()
    for db in _scan_blastdb_dir():
        if db["path"] not in seen_paths:
            db["name"] = names.get(os.path.basename(db["path"]), db["name"].replace("_", " "))
            results.append(db)

    return response_2000(data={"databases": results})


# ── Admin endpoints ──

@router.get("/admin/blast/databases", summary="管理端：列出所有 FASTA 文件及索引状态")
def admin_list_databases(db: Session = Depends(get_db), _user=Depends(get_active_user)):
    """List ALL registered FASTA files with BLAST index status."""
    from apps.datasets.models import AssetFile, DatasetAsset, DatasetVersion, DatasetRegistry

    results = []
    fasta_files = db.query(AssetFile, DatasetAsset, DatasetRegistry).join(
        DatasetAsset, AssetFile.dataset_asset_id == DatasetAsset.id
    ).join(
        DatasetVersion, DatasetAsset.dataset_version_id == DatasetVersion.id
    ).join(
        DatasetRegistry, DatasetVersion.database_id == DatasetRegistry.database_id
    ).filter(
        AssetFile.file_format.in_([
            "fa", "fasta", "fna", "faa", "fa.gz", "fasta.gz", "fna.gz", "faa.gz"
        ]),
        DatasetVersion.is_current == 1,
    ).all()

    for af, asset, reg in fasta_files:
        fp = af.local_path or af.storage_uri or ""
        if not fp or not os.path.exists(fp):
            continue
        db_type = _guess_db_type_from_name(af.file_name or "", af.file_format or "")
        base_name = af.file_name.rsplit(".", 1)[0] if "." in (af.file_name or "") else (af.file_name or "unknown")
        db_key = f"{reg.dataset_code}_{base_name}".replace(" ", "_").replace("/", "_")[:50]
        idx_path = os.path.join(_get_blastdb_dir(), db_key)
        indexed = os.path.exists(idx_path + ".phr") or os.path.exists(idx_path + ".nhr")
        names = _load_db_names()
        display_name = names.get(db_key, "") or _build_db_name(reg.title or reg.dataset_code, af.file_name or "", af.file_role or "", af.file_format or "")
        results.append({
            "id": af.id, "name": af.file_name, "display_name": display_name,
            "db_key": db_key, "path": fp,
            "format": af.file_format, "type": db_type,
            "size": af.file_size or 0,
            "dataset": reg.title or reg.dataset_code,
            "dataset_code": reg.dataset_code,
            "lifecycle": reg.lifecycle_state,
            "visibility": reg.visibility,
            "indexed": indexed,
        })
        })

    results.extend(_scan_blastdb_dir())
    return response_2000(data={"databases": results})


@router.post("/admin/blast/databases/{file_id}/index", summary="管理端：为 FASTA 文件建立 BLAST 索引")
def admin_create_index(file_id: int, db: Session = Depends(get_db), _user=Depends(get_active_user)):
    """Run makeblastdb, saving indexes to the unified BLASTDB_DIR."""
    from apps.datasets.models import AssetFile, DatasetAsset, DatasetVersion, DatasetRegistry

    af = db.query(AssetFile).filter_by(id=file_id).first()
    if not af:
        raise HTTPException(status_code=404, detail="File not found")

    fp = af.local_path or af.storage_uri or ""
    if not fp or not os.path.exists(fp):
        raise HTTPException(status_code=400, detail=f"File not found on disk: {fp}")

    db_type = _guess_db_type_from_name(af.file_name or "", af.file_format or "")

    # Get dataset name for the output title
    asset = db.query(DatasetAsset).filter_by(id=af.dataset_asset_id).first()
    dataset_name = "unknown"
    if asset:
        ver = db.query(DatasetVersion).filter_by(id=asset.dataset_version_id).first()
        if ver:
            reg = db.query(DatasetRegistry).filter_by(database_id=ver.database_id).first()
            if reg:
                dataset_name = (reg.dataset_code or f"ds{ver.database_id}")

    # Build output in unified BLASTDB_DIR
    os.makedirs(_get_blastdb_dir(), exist_ok=True)
    base_name = af.file_name.rsplit(".", 1)[0] if "." in (af.file_name or "") else (af.file_name or "blastdb")
    title = f"{dataset_name}_{base_name}".replace(" ", "_").replace("/", "_")[:50]
    out_path = os.path.join(_get_blastdb_dir(), title)

    try:
        if fp.endswith(".gz"):
            cmd = f"gunzip -c {fp} | makeblastdb -in - -dbtype {db_type} -title {title} -out {out_path} -parse_seqids 2>&1"
        else:
            cmd = f"makeblastdb -in {fp} -dbtype {db_type} -title {title} -out {out_path} -parse_seqids 2>&1"

        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=600)

        if result.returncode != 0:
            raise HTTPException(status_code=400, detail=f"makeblastdb failed: {result.stderr[:500]}")

        return response_2000(data={
            "id": file_id, "name": title, "path": out_path,
            "indexed": True, "output": result.stdout[:1000],
        })
    except subprocess.TimeoutExpired:
        raise HTTPException(status_code=400, detail="makeblastdb timed out (10 min)")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.delete("/admin/blast/databases/{file_id}/index", summary="管理端：删除 BLAST 索引文件")
def admin_delete_index(file_id: int, db: Session = Depends(get_db), _user=Depends(get_active_user)):
    """Remove BLAST index files."""
    from apps.datasets.models import AssetFile

    af = db.query(AssetFile).filter_by(id=file_id).first()
    if not af:
        raise HTTPException(status_code=404, detail="File not found")

    fp = af.local_path or af.storage_uri or ""
    extensions = [".phr", ".pin", ".psq", ".pdb", ".pog", ".pos", ".pot", ".ptf", ".pto", ".pjs",
                  ".nhr", ".nin", ".nsq", ".ndb", ".nog", ".nos", ".not", ".ntf", ".nto", ".njs"]
    removed = 0
    for ext in extensions:
        idx_path = fp + ext
        if os.path.exists(idx_path):
            os.remove(idx_path)
            removed += 1

    return response_2000(data={"id": file_id, "indexed": False, "removed": removed})
