"""BLAST plugin API router — provides BLAST-specific endpoints."""
import os, glob as _glob, subprocess, logging
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from db.database import get_db
from libs.responses.response import response_2000
from apps.common.depends import get_active_user

logger = logging.getLogger(__name__)
router = APIRouter(tags=["plugin:blast"])

BLASTDB_DIR = "/Users/kentnf/projects/data/blastdb"


def _guess_db_type_from_name(name: str, fmt: str = "") -> str:
    n = name.lower()
    if "protein" in n or "faa" in fmt:
        return "prot"
    return "nucl"


def _check_indexed(fp: str) -> bool:
    for ext in [".phr", ".pin", ".nhr", ".nin"]:
        if os.path.exists(fp + ext):
            return True
    return False


def _scan_blastdb_dir() -> list[dict]:
    """Scan pre-built BLAST databases from BLASTDB_DIR."""
    results = []
    if not os.path.isdir(BLASTDB_DIR):
        return results
    seen = set()
    for pattern in ["*.phr", "*.nhr"]:
        for idx_file in _glob.glob(os.path.join(BLASTDB_DIR, pattern)):
            base = idx_file[:-4]
            if base in seen:
                continue
            seen.add(base)
            name = os.path.basename(base)
            db_type = "prot" if os.path.exists(base + ".pin") or os.path.exists(base + ".phr") else "nucl"
            if os.path.exists(base + ".nhr") or os.path.exists(base + ".nin"):
                db_type = "nucl"
            results.append({
                "id": 0, "name": name, "path": base,
                "format": "blastdb", "type": db_type,
                "size": 0, "dataset": "Pre-built BLAST DB",
                "dataset_code": name, "indexed": True,
            })
    return results


# ── Public endpoint ──

@router.get("/blast/databases", summary="列出可用的 BLAST 数据库")
def list_blast_databases(db: Session = Depends(get_db)):
    """List registered FASTA files + pre-built BLAST databases."""
    from apps.datasets.models import AssetFile, DatasetAsset, DatasetVersion, DatasetRegistry

    results = []
    fasta_files = db.query(AssetFile, DatasetAsset, DatasetRegistry).join(
        DatasetAsset, AssetFile.dataset_asset_id == DatasetAsset.id
    ).join(
        DatasetVersion, DatasetAsset.dataset_version_id == DatasetVersion.id
    ).join(
        DatasetRegistry, DatasetVersion.database_id == DatasetRegistry.database_id
    ).filter(
        AssetFile.file_format.in_([
            "fa", "fasta", "fna", "faa", "fa.gz", "fasta.gz", "fna.gz", "faa.gz"
        ]),
        DatasetVersion.is_current == 1,
        DatasetRegistry.visibility == "public",
    ).all()

    for af, asset, reg in fasta_files:
        fp = af.local_path or af.storage_uri or ""
        if not fp or not os.path.exists(fp):
            continue
        results.append({
            "id": af.id, "name": af.file_name, "path": fp,
            "format": af.file_format, "type": _guess_db_type_from_name(af.file_name or "", af.file_format or ""),
            "size": af.file_size or 0,
            "dataset": reg.title or reg.dataset_code,
            "dataset_code": reg.dataset_code,
            "indexed": _check_indexed(fp),
        })

    # Add pre-built BLAST DBs
    results.extend(_scan_blastdb_dir())

    return response_2000(data={"databases": results})


# ── Admin endpoints ──

@router.get("/admin/blast/databases", summary="管理端：列出所有 FASTA 文件及索引状态")
def admin_list_databases(db: Session = Depends(get_db), _user=Depends(get_active_user)):
    """List ALL registered FASTA files with BLAST index status."""
    from apps.datasets.models import AssetFile, DatasetAsset, DatasetVersion, DatasetRegistry

    results = []
    fasta_files = db.query(AssetFile, DatasetAsset, DatasetRegistry).join(
        DatasetAsset, AssetFile.dataset_asset_id == DatasetAsset.id
    ).join(
        DatasetVersion, DatasetAsset.dataset_version_id == DatasetVersion.id
    ).join(
        DatasetRegistry, DatasetVersion.database_id == DatasetRegistry.database_id
    ).filter(
        AssetFile.file_format.in_([
            "fa", "fasta", "fna", "faa", "fa.gz", "fasta.gz", "fna.gz", "faa.gz"
        ]),
        DatasetVersion.is_current == 1,
    ).all()

    for af, asset, reg in fasta_files:
        fp = af.local_path or af.storage_uri or ""
        if not fp or not os.path.exists(fp):
            continue
        results.append({
            "id": af.id, "name": af.file_name, "path": fp,
            "format": af.file_format, "type": _guess_db_type_from_name(af.file_name or "", af.file_format or ""),
            "size": af.file_size or 0,
            "dataset": reg.title or reg.dataset_code,
            "dataset_code": reg.dataset_code,
            "lifecycle": reg.lifecycle_state,
            "visibility": reg.visibility,
            "indexed": _check_indexed(fp),
        })

    results.extend(_scan_blastdb_dir())
    return response_2000(data={"databases": results})


@router.post("/admin/blast/databases/{file_id}/index", summary="管理端：为 FASTA 文件建立 BLAST 索引")
def admin_create_index(file_id: int, db: Session = Depends(get_db), _user=Depends(get_active_user)):
    """Run makeblastdb for a registered FASTA file."""
    from apps.datasets.models import AssetFile

    af = db.query(AssetFile).filter_by(id=file_id).first()
    if not af:
        raise HTTPException(status_code=404, detail="File not found")

    fp = af.local_path or af.storage_uri or ""
    if not fp or not os.path.exists(fp):
        raise HTTPException(status_code=400, detail=f"File not found on disk: {fp}")

    db_type = _guess_db_type_from_name(af.file_name or "", af.file_format or "")
    title = af.file_name.rsplit(".", 1)[0] if "." in (af.file_name or "") else (af.file_name or "blastdb")

    try:
        if fp.endswith(".gz"):
            cmd = f"gunzip -c {fp} | makeblastdb -in - -dbtype {db_type} -title {title} -parse_seqids 2>&1"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=600)
        else:
            cmd = f"makeblastdb -in {fp} -dbtype {db_type} -title {title} -parse_seqids"
            result = subprocess.run(cmd.split(), capture_output=True, text=True, timeout=600)

        if result.returncode != 0:
            raise HTTPException(status_code=400, detail=f"makeblastdb failed: {result.stderr[:500]}")

        return response_2000(data={"id": file_id, "indexed": _check_indexed(fp), "output": result.stdout[:1000]})
    except subprocess.TimeoutExpired:
        raise HTTPException(status_code=400, detail="makeblastdb timed out (10 min)")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.delete("/admin/blast/databases/{file_id}/index", summary="管理端：删除 BLAST 索引文件")
def admin_delete_index(file_id: int, db: Session = Depends(get_db), _user=Depends(get_active_user)):
    """Remove BLAST index files."""
    from apps.datasets.models import AssetFile

    af = db.query(AssetFile).filter_by(id=file_id).first()
    if not af:
        raise HTTPException(status_code=404, detail="File not found")

    fp = af.local_path or af.storage_uri or ""
    extensions = [".phr", ".pin", ".psq", ".pdb", ".pog", ".pos", ".pot", ".ptf", ".pto", ".pjs",
                  ".nhr", ".nin", ".nsq", ".ndb", ".nog", ".nos", ".not", ".ntf", ".nto", ".njs"]
    removed = 0
    for ext in extensions:
        idx_path = fp + ext
        if os.path.exists(idx_path):
            os.remove(idx_path)
            removed += 1

    return response_2000(data={"id": file_id, "indexed": False, "removed": removed})
