"""BLAST tool — nucleotide and protein sequence similarity search."""
import os, re, subprocess, tempfile
from basis.analysis.base import (
    BaseAnalysisTool, TextParam, ChoiceParam, FloatParam, IntParam, FileOutput,
)

BLAST_DB_PATHS = {
    "nr": "/Users/kentnf/projects/data/blastdb/nr",
    "swissprot": "/Users/kentnf/projects/data/blastdb/swissprot",
    "tair": "/Users/kentnf/projects/data/blastdb/TAIR10_pep",
}

class BlastTool(BaseAnalysisTool):
    tool_id = "blast"
    tool_version = "1.0.0"
    display_name = "BLAST"
    description = "BLAST sequence similarity search against public databases (nr, Swiss-Prot, TAIR)."
    category = "utility"

    inputs = []

    parameters = [
        TextParam(name="query_seq", label="Query Sequence (FASTA)", default="",
                  description="Paste one or more sequences in FASTA format."),
        ChoiceParam(name="database", label="Database",
                    choices=["nr", "swissprot", "tair"], default="nr"),
        ChoiceParam(name="seq_type", label="Sequence Type",
                    choices=["auto", "nucleotide", "protein"], default="auto"),
        FloatParam(name="evalue", label="E-value Threshold", default=1e-5, min=1e-100, max=1000),
        IntParam(name="max_hits", label="Max Hits", default=50, min=1, max=500),
    ]

    outputs = [
        FileOutput(name="blast_table", format="tsv", label="BLAST Results", display="table"),
        FileOutput(name="blast_report", format="txt", label="Full Report", display="download"),
    ]

    timeout_seconds = 600
    dependencies = {"conda": ["blast"]}

    def build_command(self, file_paths: dict, params: dict, work_dir: str) -> list:
        query_seq = params.get("query_seq", "")
        database = params.get("database", "nr")
        seq_type = params.get("seq_type", "auto")
        evalue = params.get("evalue", 1e-5)
        max_hits = params.get("max_hits", 50)

        db_path = BLAST_DB_PATHS.get(database, "")
        if not db_path or not os.path.exists(db_path + ".phr") and not os.path.exists(db_path + ".pin"):
            # Write fallback message
            script = f'''
import os
os.chdir("{work_dir}")
with open("{work_dir}/blast_table.tsv", "w") as f:
    f.write("Error\\tBLAST database '{database}' is not configured on this server.\\n")
with open("{work_dir}/blast_report.txt", "w") as f:
    f.write("BLAST database '{database}' is not configured on this server.\\n")
'''
        else:
            script = self._generate_script(work_dir, query_seq, db_path, database, seq_type, evalue, max_hits)

        script_path = os.path.join(work_dir, "run_blast.py")
        with open(script_path, "w") as f:
            f.write(script)
        return ["python", script_path]

    def validate_outputs(self, work_dir: str) -> list:
        found = []
        for name in ["blast_table.tsv", "blast_report.txt"]:
            p = os.path.join(work_dir, name)
            if os.path.exists(p):
                found.append(p)
        return found

    def _generate_script(self, work_dir, query_seq, db_path, database, seq_type, evalue, max_hits):
        return f'''
import os, subprocess, tempfile, re

os.chdir("{work_dir}")

# Write query FASTA
query_fa = os.path.join("{work_dir}", "query.fa")
with open(query_fa, "w") as f:
    f.write("""{query_seq}""")

# Detect sequence type
def detect_seq_type(fasta_path):
    with open(fasta_path) as f:
        seq = ""
        for line in f:
            if not line.startswith(">"):
                seq += line.strip().upper()
        dna_chars = set("ATCGN")
        non_dna = sum(1 for c in seq if c.isalpha() and c not in dna_chars)
        if len(seq) > 0 and non_dna / len(seq) > 0.1:
            return "protein"
    return "nucleotide"

st = detect_seq_type(query_fa) if "{seq_type}" == "auto" else "{seq_type}"

# Choose blast program
if st == "protein":
    program = "blastp"
else:
    program = "blastn"

print(f"Running {{program}} against {{db_path}} ...")

# Run BLAST
outfmt = "6 qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue bitscore stitle"
cmd = [
    program, "-query", query_fa, "-db", "{db_path}",
    "-evalue", str({evalue}), "-max_target_seqs", str({max_hits}),
    "-outfmt", outfmt, "-out", "{work_dir}/blast_table.tsv",
]
result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)

# Full report
cmd2 = [
    program, "-query", query_fa, "-db", "{db_path}",
    "-evalue", str({evalue}), "-max_target_seqs", str({max_hits}),
    "-out", "{work_dir}/blast_report.txt",
]
subprocess.run(cmd2, capture_output=True, text=True, timeout=300)

# Add header to TSV
if os.path.exists("{work_dir}/blast_table.tsv"):
    with open("{work_dir}/blast_table.tsv") as f:
        content = f.read()
    with open("{work_dir}/blast_table.tsv", "w") as f:
        f.write("Query\\tSubject\\tIdentity%\\tLength\\tMismatch\\tGapOpen\\tQStart\\tQEnd\\tSStart\\tSEnd\\tEvalue\\tBitScore\\tDescription\\n")
        f.write(content)

print(f"BLAST complete. stderr: {{result.stderr[:200]}}")
'''
